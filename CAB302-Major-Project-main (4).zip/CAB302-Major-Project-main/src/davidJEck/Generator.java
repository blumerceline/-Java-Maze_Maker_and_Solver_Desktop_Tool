package davidJEck;

import mazeCreation.MainMazeUI;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

/**
 * The base class for generating mazes. Contains functionality to display a maze
 */
public abstract class Generator extends JPanel implements Runnable {
    int[][] maze; // Description of state of maze.  The value of maze[i][j]
    // is one of the constants wallCode, pathcode, emptyCode,
    // or visitedCode.  (Value can also be negative, temporarily,
    // inside createMaze().)
    //    A maze is made up of walls and corridors.  maze[i][j]
    // is either part of a wall or part of a corridor.  A cell
    // cell that is part of a corridor is represented by pathCode
    // if it is part of the current path through the maze, by
    // visitedCode if it has already been explored without finding
    // a solution, and by emptyCode if it has not yet been explored.
    final public static int backgroundCode = 0;
    final public static int wallCode = 1;
    final public static int pathCode = 2;
    final public static int emptyCode = 3;
    final public static int visitedCode = 4;

    final static Color[] color = {  // colors associated with the preceding 5 constants;
            new Color(255, 255, 255),        // Background
            new Color(1, 1, 1),              // Wall
            new Color(128, 128, 255),        // Solved Path
            new Color(255, 255, 255, 0),  // Empty
            new Color(200, 200, 200)         // Visited
    };

    int rows;            // number of rows of cells in maze, including a wall around edges
    int columns;         // number of columns of cells in maze, including a wall around edges
    int border = 20;     // minimum number of pixels between maze and edge of panel
    int speedSleep = 3;  // short delay between steps in making and solving maze
    int blockSize;       // size of each cell. Determined by panel size

    int width = -1;   // width of panel, to be set by checkSize()
    int height = -1;  // height of panel, to be set by checkSize()

    int totalWidth;   // width of panel, minus border area (set in checkSize())
    int totalHeight;  // height of panel, minus border area (set in checkSize())
    int left;         // left edge of maze, allowing for border (set in checkSize())
    int top;          // top edge of maze, allowing for border (set in checkSize())

    public int imageScale;

    boolean mazeExists = false; // set to true when maze[][] is valid;
    boolean generationComplete = false; // set to true when maze[][] is valid;

    Image logoImage;
    Image startImage;
    Image endImage;
    Image scaledLogoImage;
    Image scaledStartImage;
    Image scaledEndImage;

    Point mousePosition;


    /**
     * Constructor, performs checks to ensure the maze dimensions are odd numbers, sets colours,
     * and allows user to make changes to the maze by clicking a cell
     *
     * @param rows       Number of rows in the maze
     * @param columns    Number of columns in the maze
     * @param dimension  Dimension of the panel the maze should fit in
     * @param logoImage  Image displayed in the center of the maze, null if none
     * @param startImage Image displayed at the top left of the maze, null if none
     * @param endImage   Image displayed at the bottom right of the maze, null if none
     */
    public Generator(int rows, int columns, Dimension dimension,
                     Image logoImage, Image startImage, Image endImage) {

        // set rows and cols, ensuring they are odd numbers. Add 2 for the edges around the maze.
        this.rows = (rows % 2 == 0) ? rows + 3 : rows + 2;
        this.columns = (columns % 2 == 0) ? columns + 3 : columns + 2;
        this.imageScale = (rows + columns) / 10 * 2 / 2;  // TODO: make this user changeable
        this.logoImage = logoImage;
        this.startImage = startImage;
        this.endImage = endImage;

        resizeMaze(dimension);  // Sets blockSize and image sizes
        setBackground(color[backgroundCode]);
        setPreferredSize(new Dimension(this.blockSize * this.columns + border * 2, blockSize * this.rows + border * 2));
        new Thread(this).start();
    }


    /**
     * Paints all components to the screen when repaint() is called
     *
     * @param g graphics object
     */
    @Override
    synchronized protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        checkSize();

        if (scaledLogoImage != null) {
            int imScale = (imageScale % 2 == 0) ? imageScale / 2 : imageScale / 2 - 1; // Force an even placement
            // The maze is always an uneven number, therefore we will always need a half offset of blockSize to the maze half-size
            int posX = left + (totalWidth / 2) - (blockSize / 2) - (imScale * blockSize);
            int posY = top + (totalHeight / 2) - (blockSize / 2) - (imScale * blockSize);
            g.drawImage(scaledLogoImage, posX, posY, this);
        }

        if (scaledStartImage != null) {
            int posX = left + blockSize;
            int posY = top + blockSize;
            g.drawImage(scaledStartImage, posX, posY, this);
        }

        if (scaledEndImage != null) {
            int posX = left + totalWidth - scaledEndImage.getWidth(this) - blockSize;
            int posY = top + totalHeight - scaledEndImage.getHeight(this) - blockSize;
            g.drawImage(scaledEndImage, posX, posY, this);
        }
        redrawMaze(g);
    }


    @Override
    public String toString() {
        return Arrays.deepToString(maze);
    }


    /**
     * checks width and height of maze, sets parameters used for drawing,
     */
    private void checkSize() {
        // Called before drawing the maze, to set parameters used for drawing.
        if (getWidth() != width || getHeight() != height) {
            width = getWidth();
            height = getHeight();
            int w = (width - 2 * border) / columns;
            int h = (height - 2 * border) / rows;
            left = (width - w * columns) / 2;
            top = (height - h * rows) / 2;
            totalWidth = w * columns;
            totalHeight = h * rows;
        }
    }


    /**
     * redrawMaze is used to draw and display the entire maze
     *
     * @param g graphics object
     */
    private void redrawMaze(Graphics g) {
        // draws the entire maze
        if (mazeExists) {
            int w = totalWidth / columns;  // width of each cell
            int h = totalHeight / rows;    // height of each cell
            for (int j = 0; j < columns; j++) {
                for (int i = 0; i < rows; i++) {
                    if (maze[i][j] < 0)
                        g.setColor(color[emptyCode]);
                    else
                        g.setColor(color[maze[i][j]]);
                    g.fillRect((j * w) + left, (i * h) + top, w, h);
                }
            }
            g.setColor(Color.blue);
            g.fillPolygon(new int[]{10, 10, 30}, new int[]{30, 50, 40}, 3);
            g.fillPolygon(new int[]{getWidth() - 30, getWidth() - 30, getWidth() - 10}, new int[]{getHeight() - 50, getHeight() - 30, getHeight() - 40}, 3);
            g.setColor(Color.BLACK);
        }
    }


    /**
     * This should always be overridden
     */
    protected void makeMaze() {
    }


    /**
     * Uses DFS to try and solve the maze by continuing current path from position (row, col)
     *
     * @param row maze starting point
     * @param col maze starting point
     * @return True if a solution was found, false otherwise
     */
    public boolean solveMaze(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= columns) return false; // Stops solver from going out of bounds
        if (maze[row][col] == emptyCode) {
            maze[row][col] = pathCode;      // add this cell to the path
            repaint();
            if (row == rows - 2 && col == columns - 2)
                return true;  // path has reached goal
            try {
                Thread.sleep(speedSleep);
            } catch (InterruptedException e) {
                MainMazeUI.displayError("Solve maze was interrupted: " + e.getMessage());
            }

            if (solveMaze(row - 1, col) ||     // try to solve maze by extending path
                    solveMaze(row, col - 1) ||     //    in each possible direction
                    solveMaze(row + 1, col) ||
                    solveMaze(row, col + 1))
                return true;
            // maze can't be solved from this cell, so backtrack out of the cell
            maze[row][col] = visitedCode;   // mark cell as having been visited
            repaint();
            synchronized (this) {
                try {
                    wait(speedSleep);
                } catch (InterruptedException e) {
                    MainMazeUI.displayError("Solve maze was interrupted: " + e.getMessage());
                }
            }
        }
        return false;
    }


    /**
     * Loops through the maze array, finds empty cells and repaints them to the original colour
     */
    public void unsolveMaze() {
        for (int i = 0; i < rows; i++) {  // iterate through all cells
            for (int j = 0; j < columns; j++) {
                if (maze[i][j] != wallCode) {
                    maze[i][j] = emptyCode;      // change path code to empty
                }
            }
        }
        repaint();
    }


    /**
     * Finds the percentage of cells reached by the solution in the maze
     *
     * @return cellsReached - the total number of cells reached by the solution in the maze divided with the
     * number of empty cells times by 100 to get a percentage
     */
    public double cellsReachedBySolution() {
        double cellsReached = 0.0;
        int emptyCounter = 0;
        for (int i = 1; i < rows - 1; i++) {  // iterate through all cells
            for (int j = 1; j < columns - 1; j++) {
                if (maze[i][j] != wallCode) {
                    emptyCounter++;
                    // cells reached by path code
                    if (maze[i][j] == pathCode) {
                        cellsReached = cellsReached + 1;
                    }
                }
            }
        }
        return (cellsReached / emptyCounter) * 100;
    }


    /**
     * Finds and returns the percentage of dead ends in the maze
     *
     * @return deadEnds - the total number of dead ends in the maze divided with the
     * number of empty cells times by 100 to get a percentage
     */
    public double numberOfDeadEnds() {
        double deadEnds = 0;
        int emptyCounter = 0;
        for (int i = 1; i < rows - 1; i++) {  // iterate through all cells
            for (int j = 1; j < columns - 1; j++) {
                if (maze[i][j] == wallCode) continue;
                emptyCounter++;
                if (maze[i - 1][j] == wallCode && maze[i][j + 1] == wallCode && maze[i][j - 1] == wallCode) {
                    deadEnds = deadEnds + 1;
                    continue;
                }
                if (maze[i + 1][j] == wallCode && maze[i][j + 1] == wallCode && maze[i][j - 1] == wallCode) {
                    deadEnds = deadEnds + 1;
                    continue;
                }
                if (maze[i][j + 1] == wallCode && maze[i - 1][j] == wallCode && maze[i + 1][j] == wallCode) {
                    deadEnds = deadEnds + 1;
                    continue;
                }
                if (maze[i][j - 1] == wallCode && maze[i - 1][j] == wallCode && maze[i + 1][j] == wallCode) {
                    deadEnds = deadEnds + 1;
                }
            }
        }
        return (deadEnds / emptyCounter) * 100;
    }


    /**
     * Checks if a cell is in the same space as a part of an image
     *
     * @param row The row of the cell
     * @param col The column of the cell
     * @return True if the cell is in an images space, false otherwise
     */
    protected boolean cellInImageSpace(int row, int col) {
        if (scaledLogoImage != null) {
            int width = scaledLogoImage.getWidth(this) / blockSize;
            int height = scaledLogoImage.getHeight(this) / blockSize;

            // Check width, check height. /2 because it is in the center. -1 because of the cells bordering the maze
            int fixBigMazeIssue = (rows > 96 || columns > 96) ? 0 : 1; // Hacky solution to an issue with larger mazes
            int innerRows = (rows) / 2 + height / 2 - fixBigMazeIssue;
            int innerCols = (columns) / 2 + width / 2 - fixBigMazeIssue;
            // Check width, check height, return true if in these bounds
            if (col > innerCols - width && col <= innerCols && row > innerRows - height && row <= innerRows) {
                return true;
            }
        }

        if (scaledStartImage != null) {
            int width = scaledStartImage.getWidth(this) / blockSize;
            int height = scaledStartImage.getHeight(this) / blockSize;

            if (col > 0 && col <= width && row > 0 && row <= height) return true;
        }

        if (scaledEndImage != null) {
            int width = scaledEndImage.getWidth(this) / blockSize;
            int height = scaledEndImage.getHeight(this) / blockSize;

            int innerRows = rows - 2;  // -2 because of the cells bordering the maze
            int innerCols = columns - 2;
            return col > innerCols - width && col <= innerCols && row > innerRows - height && row <= innerRows;
        }
        return false;
    }


    /**
     * Clears walls that appear in image space
     */
    private void clearWallsInImageSpace() {
        // Iterate through all cells
        for (int i = 1; i < rows - 1; i++) {
            for (int j = 1; j < columns - 1; j++) {
                if (cellInImageSpace(i, j)) maze[i][j] = emptyCode;
            }
        }
    }


    /**
     * Get the cell at the screen position
     *
     * @param position position of mouse
     * @return The coordinates of cell as a point(row, col)
     */
    protected Point ScreenPosToMazePos(Point position) {
        int mouseX = position.x;
        int mouseY = position.y;
        int x = (mouseX - left) / (blockSize);
        int y = (mouseY - top) / (blockSize);
        return new Point(x, y);
    }


    /**
     * Sets the cell at position as code.
     *
     * @param position position of cell given as point(x, y)
     * @param code     Constant code to set cell as. eg. wallCode
     */
    protected void setCell(Point position, int code) {
        if (!generationComplete) return;
        if (position.x < 0 || position.x >= rows || position.y < 0 || position.y >= columns) return;
        //if (cellInImageSpace(position.y, position.x)) return;
        if (maze[position.x][position.y] != code) {
            maze[position.x][position.y] = code;
        }
        repaint();
    }


    /**
     * Used to calculate the block size based on the size of a panel.
     *
     * @param dimension dimension of the panel to adjust to
     * @return returns the block size
     */
    private int calculateBlockSize(Dimension dimension) {
        int height = dimension.height - border * 2;
        int width = dimension.width - border * 2;
        if (columns > rows) {
            return width / columns;
        }
        return height / rows;
    }


    /**
     * Takes a Dimension and resizes the maze to fit into it
     *
     * @param dimension The dimension of the panel it needs to fit in.
     */
    public void resizeMaze(Dimension dimension) {
        if (dimension.width < 1 || dimension.height < 1) return;

        this.blockSize = calculateBlockSize(dimension);
        setSize(new Dimension(blockSize * columns + border * 2, blockSize * rows + border * 2));
        setLocation(dimension.width / 2 - blockSize * columns / 2, 0);

        scaledLogoImage = rescaleImage(logoImage);
        scaledStartImage = rescaleImage(startImage);
        scaledEndImage = rescaleImage(endImage);
        repaint();
    }


    /**
     * Scale a given image to fit into the maze cells.
     * Scales to imageScale field.
     *
     * @param image The image to resize, logoImage, StartImage, or endImage
     * @return Returns the scaled image, or null if no image
     */
    private Image rescaleImage(Image image) {
        if (image == null) return null;
        int width = image.getWidth(this);
        int height = image.getHeight(this);

        // I honestly have no idea what I'm doing, but it works :shrug:
        int scale = (height > width) ? width / imageScale : height / imageScale;

        return image.getScaledInstance(
                width / scale * blockSize,
                height / scale * blockSize,
                Image.SCALE_SMOOTH);
    }


    /**
     * Set the image that will display at the center of the maze.
     *
     * @param logoImage Image to display
     */
    public void setLogoImage(Image logoImage) {
        this.logoImage = logoImage;
        scaledLogoImage = rescaleImage(logoImage);
        clearWallsInImageSpace();
        repaint();
    }


    /**
     * Set the image that will display at the top left of the maze.
     *
     * @param startImage Image to display
     */
    public void setStartImage(Image startImage) {
        this.startImage = startImage;
        scaledStartImage = rescaleImage(startImage);
        clearWallsInImageSpace();
        repaint();
    }


    /**
     * Set the image that will display at the bottom right of the maze.
     *
     * @param endImage Image to display
     */
    public void setEndImage(Image endImage) {
        this.endImage = endImage;
        scaledEndImage = rescaleImage(endImage);
        clearWallsInImageSpace();
        repaint();
    }


    public void setSpeedSleep(int value) { speedSleep = value; }

    public int[][] getMaze() { return maze; }

    public Image getLogoImage() {
        return logoImage;
    }

    public Image getStartImage() {
        return startImage;
    }

    public Image getEndImage() {
        return endImage;
    }
}
