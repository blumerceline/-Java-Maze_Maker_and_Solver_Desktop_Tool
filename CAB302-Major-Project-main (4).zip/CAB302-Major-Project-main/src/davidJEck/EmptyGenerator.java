package davidJEck;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * Public class EmptyGenerator creates an empty maze with a border around it
 */
public class EmptyGenerator extends Generator {

    /**
     * Constructor, allows for manual creation and editing of maze.
     *
     * @param rows      Number of rows in the maze
     * @param columns   Number of columns in the maze
     * @param dimension dimension of the panel the maze should fit in
     */
    public EmptyGenerator(int rows, int columns, Dimension dimension,
                          Image logoImage, Image startImage, Image endImage) {

        super(rows, columns, dimension, logoImage, startImage, endImage);

        this.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });
    }


    @Override
    public void run() {
        makeMaze();
    }


    /**
     * Creates an empty maze with a border around it
     */
    protected void makeMaze() {
        if (maze == null)
            maze = new int[rows][columns];
        int i, j;
        int emptyCt = 0; // number of rooms
        int wallCt = 0;  // number of walls
        int[] wallrow = new int[(rows * columns) / 2];  // position of walls between rooms
        int[] wallcol = new int[(rows * columns) / 2];
        for (i = 0; i < rows; i++)  // start with everything being a wall
            for (j = 0; j < columns; j++)
                // Create an empty maze with a border around it
                if (i == 0 || j == 0 || i == rows - 1 || j == columns - 1) maze[i][j] = wallCode;
                else maze[i][j] = emptyCode;

        mazeExists = true;
        generationComplete = true;
        repaint();
    }
}
