package davidJEck;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * Public Class LoadedGenerator constructs a maze with space for start and end images
 */
public class LoadedGenerator extends Generator {

    /**
     * Load a maze into a generator so that it can be displayed on the screen and used like other mazes.
     *
     * @param dimension  Dimension of the panel the maze should fit in
     * @param array      Array of the maze that will be loaded
     * @param logoImage  Image displayed in the center of the maze, null if none
     * @param startImage Image displayed at the top left of the maze, null if none
     * @param endImage   Image displayed at the bottom right of the maze, null if none
     */
    public LoadedGenerator(Dimension dimension, int[][] array,
                           Image logoImage, Image startImage, Image endImage) {

        super(array.length - 2, array[1].length - 2, dimension, logoImage, startImage, endImage);
        maze = array;

        this.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });
    }

    /**
     * For testing only. use with caution.
     * @param array The array of the maze to load
     */
    public LoadedGenerator(int[][] array) {
        super(array.length - 2, array[1].length - 2, new Dimension(5, 5), null, null, null);
        this.maze = array;
    }


    @Override
    public void run() {
        makeMaze();
    }


    /**
     * Sets the necessary variables that allows a maze to draw and be edited.
     */
    protected void makeMaze() {
        mazeExists = true;
        generationComplete = true;
        repaint();
    }
}