package davidJEck;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * Public class AutoGenerator extends abstract class Generator, AutoGenerator automatically generates a maze.
 */
public class AutoGenerator extends Generator {

    /**
     * Constructor, performs checks to ensure the maze dimensions are odd numbers, sets colours,
     * and allows user to make changes to the maze by clicking a cell
     *
     * @param rows      Number of rows in the maze
     * @param columns   Number of columns in the maze
     * @param dimension dimension of the panel the maze should fit in
     */
    public AutoGenerator(int rows, int columns, Dimension dimension,
                         Image logoImage, Image startImage, Image endImage) {

        super(rows, columns, dimension, logoImage, startImage, endImage);

        this.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, wallCode);

                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mousePosition = ScreenPosToMazePos(new Point(e.getY(), e.getX()));
                    setCell(mousePosition, emptyCode);
                }
            }
        });
    }


    @Override
    public void run() {
        makeMaze();
    }


    /**
     * Create a random maze. The strategy is to start with a grid of disconnected "rooms" separated by walls.
     * then look at each of the separating walls, in a random order. If tearing down a wall would not create a loop
     * in the maze, then tear it down.  Otherwise, leave it in place.
     */
    @Override
    protected void makeMaze() {
        maze = new int[rows][columns];
        int i, j;
        int emptyCt = 0; // number of rooms
        int wallCt = 0;  // number of walls
        int[] wallrow = new int[(rows * columns) / 2];  // position of walls between rooms
        int[] wallcol = new int[(rows * columns) / 2];
        for (i = 0; i < rows; i++)  // start with everything being a wall
            for (j = 0; j < columns; j++)
                if (cellInImageSpace(i, j)) maze[i][j] = emptyCode;
                else maze[i][j] = wallCode;
        for (i = 1; i < rows - 1; i += 2)  // make a grid of empty rooms
            for (j = 1; j < columns - 1; j += 2) {
                emptyCt++;
                maze[i][j] = -emptyCt;  // each room is represented by a different negative number
                if (i < rows - 2) {  // record info about wall below this room
                    wallrow[wallCt] = i + 1;
                    wallcol[wallCt] = j;
                    wallCt++;
                }
                if (j < columns - 2) {  // record info about wall to right of this room
                    wallrow[wallCt] = i;
                    wallcol[wallCt] = j + 1;
                    wallCt++;
                }
            }
        mazeExists = true;
        repaint();

        int r;
        for (i = wallCt - 1; i > 0; i--) {
            r = (int) (Math.random() * i);  // choose a wall randomly and maybe tear it down
            tearDown(wallrow[r], wallcol[r]);
            wallrow[r] = wallrow[i];
            wallcol[r] = wallcol[i];
        }
        for (i = 1; i < rows - 1; i++)  // replace negative values in maze[][] with emptyCode
            for (j = 1; j < columns - 1; j++)
                if (maze[i][j] < 0)
                    maze[i][j] = emptyCode;
        generationComplete = true;
        repaint();
    }


    /**
     * Tear down a wall, tearing down a wall joins two "rooms" into one "room".
     * When a wall is torn down, the room codes on one side are converted to match
     * those on the other side, so all the cells in a room have the same code
     *
     * @param row - row in maze
     * @param col - col in maze
     */
    private synchronized void tearDown(int row, int col) {
        if (row % 2 == 1 && maze[row][col - 1] != maze[row][col + 1]) {
            // row is odd; wall separates rooms horizontally
            fill(row, col - 1, maze[row][col - 1], maze[row][col + 1]);
            maze[row][col] = maze[row][col + 1];
            repaint();
            try {
                wait(speedSleep);
            } catch (InterruptedException e) {
            }
        } else if (row % 2 == 0 && maze[row - 1][col] != maze[row + 1][col]) {
            // row is even; wall separates rooms vertically
            fill(row - 1, col, maze[row - 1][col], maze[row + 1][col]);
            maze[row][col] = maze[row + 1][col];
            repaint();
            try {
                wait(speedSleep);
            } catch (InterruptedException e) {
            }
        }
    }


    /**
     * Replaces a defined cell (row, col) with another (replacedWith)
     *
     * @param row         - row in maze
     * @param col         - col in maze
     * @param replace     - cell in maze being replaced
     * @param replaceWith - cell that is replacing 'replace'
     */
    private void fill(int row, int col, int replace, int replaceWith) {
        // called by tearDown() to change "room codes".
        if (maze[row][col] == replace) {
            maze[row][col] = replaceWith;
            fill(row + 1, col, replace, replaceWith);
            fill(row - 1, col, replace, replaceWith);
            fill(row, col + 1, replace, replaceWith);
            fill(row, col - 1, replace, replaceWith);
        }
    }
}