package database;

import mazeCreation.Author;
import mazeCreation.ImageHelper;
import mazeCreation.MainMazeUI;
import mazeCreation.Maze;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

/**
 * A class that handles communication to and from the database
 */
public class DBFunctions {
    public static final String CONNECTION_ERROR = "There was an issue creating a connection to the database. Please edit the database settings and restart the application.";

    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS maze (" +
                    "'name' TEXT," +
                    "'authorID' INTEGER," +
                    "'date_created' INTEGER," +
                    "'last_edited' INTEGER," +
                    "'maze_array' TEXT" +
                    "'thumbnail' BLOB" +
                    "'logoImage' BLOB" +
                    "'startImage' BLOB" +
                    "'endImage' BLOB" +
                    ")";
    public static final String CREATE_AUTHOR_TABLE =
            "CREATE TABLE IF NOT EXISTS author (" +
                    "'authorID' INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "'authorFirstName' TEXT," +
                    "'authorLastName' TEXT," +
                    "UNIQUE(authorFirstName, authorLastName)" +
                    ")";

    // Functions to interact with the maze table
    private static final String INSERT_MAZE = "INSERT INTO maze (name, authorID, date_created, last_edited, maze_array, thumbnail, logoImage, startImage, endImage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String GET_MAZE_NAMES = "SELECT name FROM maze";
    private static final String GET_AUTHOR_ID = "SELECT authorID FROM author WHERE authorFirstName=? AND authorLastName=?";
    private static final String GET_AUTHOR_NAME = "SELECT authorFirstName, authorLastName FROM author WHERE authorID=?";
    private static final String INSERT_AUTHOR = "INSERT INTO author (authorFirstName, authorLastName) VALUES (?, ?)";
    private static final String SEARCH_MAZE = "SELECT * FROM maze WHERE ? LIKE ?";
    private static final String COUNT_SEARCH_MAZE = "SELECT COUNT(name) FROM maze WHERE ? LIKE ?";

    private PreparedStatement addMaze;
    private PreparedStatement addAuthor;
    private PreparedStatement getAuthorID;
    private PreparedStatement getAuthorName;
    private PreparedStatement getNameList;
    private PreparedStatement searchMaze;
    private PreparedStatement countSearchMaze;

    private Connection connection;


    /**
     * Initializes the connection to the database and stores all means to communicate to it.
     */
    public DBFunctions() {
        connection = DBConnection.getInstance();
        try {
            Statement st = connection.createStatement();
            st.execute(CREATE_TABLE);
            st.execute(CREATE_AUTHOR_TABLE);
            addMaze = connection.prepareStatement(INSERT_MAZE);
            getAuthorID = connection.prepareStatement(GET_AUTHOR_ID);
            getAuthorName = connection.prepareStatement(GET_AUTHOR_NAME);
            addAuthor = connection.prepareStatement(INSERT_AUTHOR);
            getNameList = connection.prepareStatement(GET_MAZE_NAMES);
            searchMaze = connection.prepareStatement(SEARCH_MAZE);
            countSearchMaze = connection.prepareStatement(COUNT_SEARCH_MAZE);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    /**
     * Adds a maze to the database.
     * 
     * @param maze Maze object which contains maze info
     * @param authorID Authors ID
     */
    public void addMaze(Maze maze, int authorID) {
        try {
            byte[] thumbnail = ImageHelper.imageToByteArray(maze.getThumbnailImage());

            // Get each image and convert it into a BLOB like object
            byte[] logoImage = ImageHelper.imageToByteArray(maze.generator.getLogoImage());
            byte[] startImage = ImageHelper.imageToByteArray(maze.generator.getStartImage());
            byte[] endImage = ImageHelper.imageToByteArray(maze.generator.getEndImage());

            // Proceed with sql shenanigans
            addMaze.setString(1, maze.getMazeName());
            addMaze.setInt(2, authorID);
            addMaze.setTimestamp(3, maze.getDateTimeCreated());
            addMaze.setTimestamp(4, maze.getDateTimeLastModified());
            addMaze.setString(5, maze.getMazeArray());
            addMaze.setBytes(6, thumbnail);
            addMaze.setBytes(7, logoImage);
            addMaze.setBytes(8, startImage);
            addMaze.setBytes(9, endImage);
            addMaze.executeUpdate();
        } catch (Exception ex) {
            MainMazeUI.displayError("Could not get the maze information from the database: " + ex.getMessage());
        }
    }


    /**
     * Add a author to the database
     * @param a Author to add
     */
    public void addAuthor(Author a) {
        try {
            addAuthor.setString(1, a.getAuthorFirst());
            addAuthor.setString(2, a.getAuthorLast());
            addAuthor.executeUpdate();
        } catch (SQLException ex) {
            int err = ex.getErrorCode();
            if (err == 19) {
                String errMsg = String.format("Author, %s %s, already existed in database", a.getAuthorFirst(), a.getAuthorLast());
            }
        }
    }


    /**
     * Get the name of an author of ID
     * @param id The ID of the author
     * @return returns an array with contents [firstName, lastName]
     */
    public String[] getAuthorName(int id) {
        String[] result = {null, null};
        try {
            getAuthorName.setInt(1, id);
            ResultSet authorName = getAuthorName.executeQuery();

            result[0] = authorName.getString("authorFirstName");
            result[1] = authorName.getString("authorLastName");

        } catch (SQLException ex) {
            MainMazeUI.displayError("Could not get the author details from the database:" + ex.getMessage());
        }
        return result;
    }


    /**
     * Get the ID of an author
     * @param author Author to get ID of
     * @return The ID
     */
    public int getAuthorID(Author author) {
        int id = -1;
        try {
            getAuthorID.setString(1, author.getAuthorFirst());
            getAuthorID.setString(2, author.getAuthorLast());
            ResultSet rs = getAuthorID.executeQuery();

            id = rs.getInt(1);

        } catch (SQLException ex) {
            MainMazeUI.displayError("Author ID could not be found.");
        }
        return id;
    }


    /**
     * Collects information of all mazes that are stored in a database
     * 
     * @return Arraylist of all mazes in the database
     * @throws SQLException if there is an issue connecting to the database
     */
    public ArrayList<List> getAllMaze() throws SQLException {
        return this.getAllMaze("", "");
    }

    /**
     * Collects information of all mazds that are stored in a database filtered to a search
     * @param searchFilter Maze name, author names, date created of modified
     * @param search The users input into the search
     * @return A compiled list of all the mazes
     * @throws SQLException if there is a problem connecting to the database
     */
    public ArrayList<List> getAllMaze(String searchFilter, String search) throws SQLException {
        ResultSet rs = null;
        ArrayList All = new ArrayList(6);

        String actualFilter = "name";
        switch (searchFilter) {
            case "Filter by":
                MainMazeUI.displayError("No filter specified, searching maze name by default");
            case "Maze name":
                actualFilter = "name";
                break;
            case "Author Last":
            case "Author First":
            case "Date Created":
            case "Date Modified":
                MainMazeUI.displayError("Apologies, this feature is incomplete. Cancelling search.");
                return null;
        }

        String countQuery;
        String query;
        ResultSet intRS = null;
        if (searchFilter.compareTo("") == 0) {
            // Get any count to determine the ArrayList max size
            countQuery = "SELECT COUNT(name) FROM maze";
            Statement stmt = connection.createStatement();
            intRS = stmt.executeQuery(countQuery);

            query = "SELECT * FROM maze";
            Statement statement = connection.createStatement();
            rs = statement.executeQuery(query);
        } else {
            countSearchMaze.setString(1, actualFilter);
            countSearchMaze.setString(2, search);
            intRS = countSearchMaze.executeQuery();

            searchMaze.setString(1, actualFilter);
            searchMaze.setString(2, search);
            rs = searchMaze.executeQuery();
        }

        int count = intRS.getInt("COUNT(name)");

        ArrayList name = new ArrayList(count);
        ArrayList authorId = new ArrayList(count);
        ArrayList dateCreated = new ArrayList(count);
        ArrayList lastEdited = new ArrayList(count);
        ArrayList mazeArray = new ArrayList(count);
        ArrayList imageList = new ArrayList(count);
        ArrayList logoImages = new ArrayList(count);
        ArrayList startImages = new ArrayList(count);
        ArrayList endImages = new ArrayList(count);

        try {
            byte[] data;
            ImageIcon imageIcon = null;

            while (rs.next()) {
                // Name function
                String mazeName = rs.getString("name");
                name.add(mazeName);

                // AuthorID function
                int id = rs.getInt("authorID");
                authorId.add(id);

                // Date created function
                Timestamp created = rs.getTimestamp("date_created");
                dateCreated.add(created);

                // Last edited
                Timestamp edited = rs.getTimestamp("last_edited");
                lastEdited.add(edited);

                // Maze array
                String array = rs.getString("maze_array");
                mazeArray.add(array);

                // Image function
                imageList.add(ImageHelper.ByteArrayToImage(rs, "thumbnail"));
                logoImages.add(ImageHelper.ByteArrayToImage(rs, "logoImage"));
                startImages.add(ImageHelper.ByteArrayToImage(rs, "startImage"));
                endImages.add(ImageHelper.ByteArrayToImage(rs, "endImage"));

                All.add(name);
                All.add(authorId);
                All.add(dateCreated);
                All.add(lastEdited);
                All.add(mazeArray);
                All.add(imageList);
                All.add(logoImages);
                All.add(startImages);
                All.add(endImages);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return All;
    }


    /**
     * Closes the database
     */
    public void close() {
        try {
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
