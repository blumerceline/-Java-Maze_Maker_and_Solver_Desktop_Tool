package database;

import mazeCreation.MainMazeUI;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * A class that encompasses the database connection
 */
public class DBConnection {
    public static final String DEFAULT_URL = "jdbc\\:sqlite\\:MazeCoDatabase.db";
    public static final String DEFAULT_SCHEMA = "";

    private static Connection instance = null;


    /**
     * Connects to the database with the db.props settings
     */
    private DBConnection() {
        Properties props = new Properties();
        FileInputStream in;
        try {
            in = new FileInputStream("./db.props");
            props.load(in);
            in.close();

            String url = props.getProperty("jdbc.url");
            String username = props.getProperty("jdbc.username");
            String password = props.getProperty("jdbc.password");
            String schema = props.getProperty("jdbc.schema");

            // Get connection - may not need username and password. SQlite doesn't have password or username
            instance = DriverManager.getConnection(url + "/" + schema, username, password);
        } catch (SQLException | IOException ex) {
            MainMazeUI.displayError(("Could not connect to the database: " + ex.getMessage()));
        }
    }


    /**
     * Get the new database connection
     * @return The connection
     */
    public static Connection getInstance() {
        if (instance == null) {
            new DBConnection();
        }
        return instance;
    }
}
