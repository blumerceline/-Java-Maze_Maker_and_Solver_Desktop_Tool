package mazeCreation;


import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * A helper class to aid in image conversion between types
 */
public class ImageHelper {

    /**
     * Read a file as an image.
     * Displays an error to the user if the file cannot be found
     *
     * @param file The file to read
     * @return The image or null if the file cannot be found
     */
    public static Image getImageFromFile(File file) {
        if (file == null) return null;
        if (!file.exists()) return null;
        try {
            return ImageIO.read(file);

        } catch (Exception e) {
            MainMazeUI.displayError(e.getMessage());
            return null;
        }
    }


    /**
     * Takes a byte array of a ImageIcon and converts it back into an Image.
     * 
     * @param rs The result set from the database
     * @param column The column of the data that you want, eg. "thumbnail
     * @return The image that was stored in the byte array
     * @throws SQLException If there is a problem with the result set
     * @throws IOException If the bytes cannot be read
     * @throws ClassNotFoundException If there is no Icon in the bytearray
     */
    public static Image ByteArrayToImage(ResultSet rs, String column) throws SQLException, IOException, ClassNotFoundException {
        Image image;
        byte[] data;
        ImageIcon imageIcon;
        InputStream is = rs.getBinaryStream(column);

        if (is == null) return null;
        data = is.readAllBytes();
        ByteArrayInputStream bs = new ByteArrayInputStream(data);
        ObjectInputStream ois = new ObjectInputStream(bs);
        imageIcon = (ImageIcon) ois.readObject();
        image = imageIcon.getImage();
        return image;
    }


    /**
     * Takes an image stores it into a byte array that can then be
     * stored in the database with setBytes
     *
     * @param image The image to turn into a byte array
     * @return byte[] of image or empty byte array if there is an error
     */
    public static byte[] imageToByteArray(Image image) throws IOException {
        // Icons are serializable, so we will turn the image into an icon
        if (image == null) return null;
        ImageIcon icon = new ImageIcon(image);

        // Then we write the ImageIcon object into a byte array via some shenanigans
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream os = new ObjectOutputStream(baos);
        os.writeObject(icon);

        return baos.toByteArray();
    }
}
