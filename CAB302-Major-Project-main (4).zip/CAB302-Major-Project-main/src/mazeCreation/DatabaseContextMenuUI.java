package mazeCreation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

public class DatabaseContextMenuUI extends JPopupMenu {

    public ArrayList mazeInfoArrayList;
    public MainMazeUI master;

    /**
     * Create a small context menu on the database screen
     */
    public DatabaseContextMenuUI() {
        JMenuItem open = new JMenuItem("Open in Editor");
        open.addActionListener(e -> master.createMaze(mazeInfoArrayList));
        add(open);
        
/*        JMenuItem exportOne = new JMenuItem("Export this maze");
        exportOne.addActionListener(e -> System.out.println("Export This Maze"));
        add(exportOne);*/

        JMenuItem exportAllSolved = new JMenuItem("Export Selected (Solved)");
        exportAllSolved.addActionListener(e -> MainMazeUI.exportAllSelectedImages(true));
        add(exportAllSolved);
        
        JMenuItem exportAllUnsolved = new JMenuItem("Export Selected (unSolved)");
        exportAllUnsolved.addActionListener(e -> MainMazeUI.exportAllSelectedImages(false));
        add(exportAllUnsolved);
    }    

    @Override
    public Point getLocation(Point rv) {
        return super.getLocation(rv);
    }
}
