package mazeCreation;

import database.DBConnection;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Objects;
import java.util.Properties;

public class UserSettingsUI extends JDialog {
    public static final String USER_FIRST_NAME = "user.firstName";
    public static final String USER_LAST_NAME = "user.lastName";
    public static final String DEFAULT_SCREEN = "defaultScreen";

    public static final String URL = "jdbc.url";
    public static final String SCHEMA = "jdbc.schema";
    public static final String USERNAME = "jdbc.username";
    public static final String PASSWORD = "jdbc.password";

    public static final String pathToUserConfig = System.getProperty("user.dir") + File.separator + "user.properties";
    public static final String pathToDBProps = System.getProperty("user.dir") + File.separator + "db.props";

    private JPanel mainPanel;
    // Author userProperties
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JComboBox defaultScreen;
    // Database userProperties
    private JTextField urlField;
    private JPasswordField passwordField;
    private JTextField usernameField;
    private JTextField schemaField;
    // Buttons
    private JButton cancelButton;
    private JButton setButton;

    private static final Properties dbProperties = new Properties();

    public UserSettingsUI(Properties properties, JTextField authorFirstName, JTextField authorLastName) throws HeadlessException {

        firstNameField.setText(properties.getProperty(USER_FIRST_NAME));
        lastNameField.setText(properties.getProperty(USER_LAST_NAME));
        defaultScreen.setSelectedItem(properties.getProperty(DEFAULT_SCREEN));

        urlField.setText(dbProperties.getProperty(URL));
        schemaField.setText(dbProperties.getProperty(SCHEMA));
        usernameField.setText(dbProperties.getProperty(USERNAME));
        passwordField.setText(dbProperties.getProperty(PASSWORD));

        setButton.addActionListener(e -> setButtonPressedAction(properties));

        cancelButton.addActionListener(e -> dispose());

        setModal(true);
        setContentPane(mainPanel);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        try {
            setIconImage(ImageIO.read(new File("icon.png")));
        } catch (IOException e) {
            MainMazeUI.displayError("Could not load application icon: " + e.getMessage());
        }

        pack();
        setLocationRelativeTo(null);  // Center the window
        setVisible(true);
    }


    private void setButtonPressedAction(Properties properties) {
        // Set the user properties
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String role = Objects.requireNonNull(defaultScreen.getSelectedItem()).toString();

        properties.setProperty(USER_FIRST_NAME, firstName);
        properties.setProperty(USER_LAST_NAME, lastName);
        properties.setProperty(DEFAULT_SCREEN, role);

        // Save the new user.properties
        try {
            saveToPropertiesFile(properties, pathToUserConfig);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        String url = urlField.getText();
        String schema = schemaField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();

        dbProperties.setProperty(URL, url);
        dbProperties.setProperty(SCHEMA, schema);
        dbProperties.setProperty(USERNAME, username);
        dbProperties.setProperty(PASSWORD, password);
        
        if (firstNameField != null) firstNameField.setText(firstName);
        if (lastNameField != null) lastNameField.setText(lastName);

        // Save the new db.props
        try {
            saveToPropertiesFile(dbProperties, pathToDBProps);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        dispose();
    }

    
    public static boolean generateProperties(Properties userProps, MainMazeUI mainMazeUI) {
        try {
            // Load userProps file
            loadPropertiesFile(userProps, pathToUserConfig);

        } catch (IOException ex) {
            // Fill the new config
            userProps.put(USER_FIRST_NAME, "");
            userProps.put(USER_LAST_NAME, "");
            userProps.put(DEFAULT_SCREEN, "Database View");

            try {
                // Create a new user config file
                saveToPropertiesFile(userProps, pathToUserConfig);
            } catch (IOException e) {
                // The userProperties file could not be created
                return false;
            }
        }
        return true;
    }


    public static void generateDBProps() {
        try {
            // Load userProperties file
            loadPropertiesFile(dbProperties, pathToDBProps);

        } catch (FileNotFoundException ex) {
            dbProperties.put(URL, DBConnection.DEFAULT_URL);
            dbProperties.put(SCHEMA, DBConnection.DEFAULT_SCHEMA);
            dbProperties.put(USERNAME, "");
            dbProperties.put(PASSWORD, "");
            try {
                saveToPropertiesFile(dbProperties, pathToDBProps);
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


    private static void loadPropertiesFile(Properties props, String path) throws IOException {
        // Check for an existing userProperties file.
        FileInputStream inputStream = new FileInputStream(path);
        props.load(inputStream);
    }


    private static void saveToPropertiesFile(Properties properties, String path) throws IOException {
        FileOutputStream out = new FileOutputStream(path);
        properties.store(out, "Last Modified");
        out.close();
    }
}
