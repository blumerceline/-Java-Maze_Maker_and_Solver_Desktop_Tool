package mazeCreation;

import davidJEck.*;
import database.DBFunctions;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.List;


/**
 * Main UI class of the MazeCo application that handles all interfacing.
 */
public class MainMazeUI extends JFrame implements Runnable {
    // Constants
    public static final String MESSAGE_FORMAT = "<html><font color='%s'>%s</font></html>";  // Format for displayed messages
    public static final String ERROR_COL = "red";    // Colour of error messages
    public static final String SUCCESS_COL = "blue"; // Colour of helpful, non-error messages

    private static final int WIDTH = 1280;
    private static final int HEIGHT = 720;

    // Important panels
    private JPanel mainPanel;
    private JPanel editorPanel;
    private JPanel databasePanel;
    private JTabbedPane tabbedPane;

    // Elements of the left-side editor options panel
    private JButton generateButton;
    private JTextField mazeNameField;
    private JSpinner sizeXSpinner;
    private JSpinner sizeYSpinner;
    private JCheckBox autoGenerateCheck;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField logoField;
    private JTextField endField;
    private JTextField startField;
    private JButton logoBrowseButton;
    private JButton startBrowseButton;
    private JButton endBrowseButton;
    private JButton saveToDBButton;

    // Elements of the top panel
    private JButton yesButton;
    private JButton noButton;
    private JButton exportMazeButton;

    // Elements of the bottom panel
    private static final JLabel feedbackMessage = new JLabel();
    private JLabel deadCellsLabel;
    private JLabel reachableCellsLabel;

    // Elements of the top panel
    private JButton settingsButton;

    // Elements of the database screen
    private JPanel databaseView;
    private JButton exportSelectedImagesButton;
    private JTextField searchTextField;
    private JComboBox searchFilter;
    private JButton searchButton;
    private JPanel bottomBar;

    // File access
    private static JFileChooser fileChooser;
    private UserSettingsUI settingsPopup;
    private File logoFile;
    private File startFile;
    private File endFile;

    private final Properties properties = new Properties();
    private DBFunctions connection = null;
    private Generator generator;
    private Maze maze;

    // initialising maze data array
    static ArrayList mazeDataArray = new ArrayList<>();

    /**
     * When constructed, initialises GUI action listeners for buttons
     */
    public MainMazeUI() {
            super("MazeCo Editor");
        // Instantiate the Database connection
        UserSettingsUI.generateDBProps();
        try {
            connection = new DBFunctions();
        } catch (Exception se) {
            displayError(DBFunctions.CONNECTION_ERROR);
        }
    
        generateButton.addActionListener(e -> createMaze());
    
        settingsButton.addActionListener(e -> settingsPopup = new UserSettingsUI(properties, firstNameField, lastNameField));
    
        exportMazeButton.addActionListener(e -> exportSingleMaze());
    
        exportSelectedImagesButton.addActionListener(e -> exportAllSelectedImages(false));
    
        // Clear images when the user clears the fields
        logoField.addActionListener(e -> {
            if (logoField.getText().equals("")) generator.setLogoImage(null);
        });

        startField.addActionListener(e -> {
            if (startField.getText().equals("")) generator.setStartImage(null);
        });

        endField.addActionListener(e -> {
            if (endField.getText().equals("")) generator.setEndImage(null);
        });

        // Open a JFileChooser when the user clicks on a browse button
        logoBrowseButton.addActionListener(e -> {
            logoFile = createFileChooser(logoField);
            if (generator != null) generator.setLogoImage(ImageHelper.getImageFromFile(logoFile));
        });

        startBrowseButton.addActionListener(e -> {
            startFile = createFileChooser(startField);
            if (generator != null) generator.setStartImage(ImageHelper.getImageFromFile(startFile));
        });

        endBrowseButton.addActionListener(e -> {
            endFile = createFileChooser(endField);
            if (generator != null) generator.setEndImage(ImageHelper.getImageFromFile(endFile));
        });
    
        // Solve the maze if a user clicks on this
        yesButton.addActionListener(e -> {
            if (generator == null) return;
            Thread thread = new Thread(() -> {
                generator.solveMaze(1, 1);
    
                // displays cells reached by solution
                double cellsTouchedByLine = generator.cellsReachedBySolution();
                reachableCellsLabel.setText("Reachable cells: " + String.format("%.2f", cellsTouchedByLine) + "%");
    
                // displays number of dead ends
                double deadCells = generator.numberOfDeadEnds();
    
                deadCellsLabel.setText("Dead end cells: " + String.format("%.2f", deadCells) + "%");
            });
            thread.start();
        });
    
        // Clear a solved maze if a user clicks on this
        noButton.addActionListener(e -> {
            if (generator == null) return;
            generator.unsolveMaze();
        });
    
        saveToDBButton.addActionListener(e -> {
            if (connection != null) {
                saveToDatabase();
            } else {
                displayError(DBFunctions.CONNECTION_ERROR);
            }
        });
    
        tabbedPane.addChangeListener(e -> createDBScreen(generateMazeCollection()));
    
        searchTextField.addActionListener(e -> searchDatabase());
        searchButton.addActionListener(e -> searchDatabase());
    
        mainPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if (generator != null) generator.resizeMaze(editorPanel.getSize());
            }
        });
    
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("closing down everything!");
                if (connection != null) {
                    connection.close();
                }
                System.exit(0);
            }
        });
    
        if (!UserSettingsUI.generateProperties(properties, this)) {
            displayError("Warning, there was a problem loading or creating a properties file. Please contact support.");
        } else {
            // Adapt to the users settings
            this.firstNameField.setText(properties.getProperty(UserSettingsUI.USER_FIRST_NAME));
            this.lastNameField.setText(properties.getProperty(UserSettingsUI.USER_LAST_NAME));
        }
    
        if (properties.getProperty("defaultScreen").compareTo("Database View") == 0) {
            tabbedPane.setSelectedComponent(databaseView);
            createDBScreen(generateMazeCollection());
        }
    }


    private void exportSingleMaze() {
        if (generator == null) return;
        Dimension size = generator.getSize();
        BufferedImage image = new BufferedImage(
                size.width, size.height,
                BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = image.createGraphics();
        generator.paint(g2);
        g2.dispose();

        File saveLocation = createFileChooser("Save");

        try {
            ImageIO.write(image, "png", new File(saveLocation.getAbsolutePath() + ".png"));
            displayMessage("Saved as: " + saveLocation.getAbsolutePath() + ".png", SUCCESS_COL);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    /**
     * Exports all the images that are selected in the database view.
     *
     * @param solved if the user wants the mazes to be solved or not.
     */
    public static void exportAllSelectedImages(boolean solved) {
        File saveLocation = createFileChooser("Save");

        Thread thread = new Thread(() -> {
            if (saveLocation == null) {
                displayMessage("Exporting of images canceled.", SUCCESS_COL);
                return;
            }
            for (int i = 0; i < mazeDataArray.size(); i++) {
                // Get the maze data
                ArrayList mazeData = (ArrayList) mazeDataArray.get(i);
                // Get the maze array itself
                int[][] array = convertStringToIntArray((String) mazeData.get(4));
                Image logo = (Image) mazeData.get(6);
                Image start = (Image) mazeData.get(7);
                Image end = (Image) mazeData.get(8);
                // Load it into a generator
                Generator loadedMaze = new LoadedGenerator(new Dimension(array.length*20, array[0].length*20), array, logo, start, end);
                loadedMaze.setSpeedSleep(1);
                //loadedMaze.resizeMaze(loadedMaze.getMazeSize());
    
                if (solved) loadedMaze.solveMaze(1,1); // The maze is already unsolved
    
                try {
                    BufferedImage img = new BufferedImage(
                            loadedMaze.getWidth(), loadedMaze.getHeight(),
                            BufferedImage.TYPE_INT_RGB);
                    Graphics2D g = img.createGraphics();
                    loadedMaze.paint(g);
                    g.dispose();
    
                    String path = saveLocation.getAbsolutePath() + (i + 1) + ".png";
                    ImageIO.write(img, "png", new File(path));
                    displayMessage("Image/s saved as: " + saveLocation.getName() + "#.png", SUCCESS_COL);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        });
        thread.start();
    }

    /**
     * Search the database for a given term
     */
    private void searchDatabase() {
        try {
            String filter = Objects.requireNonNull(searchFilter.getSelectedItem()).toString();
            String search = searchTextField.getText();
            createDBScreen(connection.getAllMaze(filter, search));
        } catch (SQLException ex) {
            displayError("Could not gather your search from the database: " + ex.getMessage());
        }
    }
    
    
    /**
     * Saves a maze to the database
     */
    private void saveToDatabase() {
        // If author not in database, save to database
        String authorFirstName = properties.getProperty(UserSettingsUI.USER_FIRST_NAME);
        String authorLastName = properties.getProperty(UserSettingsUI.USER_LAST_NAME);
        Author newAuthor = new Author(authorFirstName, authorLastName);
        connection.addAuthor(newAuthor);

        // Save maze to database
        String mazeName = mazeNameField.getText();

        int id = connection.getAuthorID(newAuthor);

        Date date = new Date();
        Timestamp ts = new Timestamp(date.getTime());
        
        // Quickly clear any solution so that saved mazes are always unsolved
        generator.unsolveMaze();

        try {
            Maze newMaze = new Maze(mazeName, generator, ts, ts);
            this.maze = newMaze;
            connection.addMaze(newMaze, id);
        } catch (MazeConstructorException ex) {
            displayError(ex.getMessage());
        }
    }


    /**
     * Creates and starts the main UI
     */
    @Override
    public void run() {
        try {
            setIconImage(ImageIO.read(new File("icon.png")));
            setContentPane(mainPanel);
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            setExtendedState(JFrame.MAXIMIZED_BOTH);        // Maximise the window
            setPreferredSize(new Dimension(WIDTH, HEIGHT)); // Size when not maximised

            createDBScreen(generateMazeCollection());

            pack();
            setVisible(true);

            // Check if we need to get the user to update their details
            boolean notValidFirstName = properties.getProperty(UserSettingsUI.USER_FIRST_NAME).compareTo("") == 0;
            boolean notValidLastName = properties.getProperty(UserSettingsUI.USER_LAST_NAME).compareTo("") == 0;

            if (notValidFirstName || notValidLastName) {
                settingsPopup = new UserSettingsUI(properties, firstNameField, lastNameField);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Allows custom creation of elements inside MainMazeUI.form
     */
    private void createUIComponents() {
        // size X and Y, constrained to 5-100      
        SpinnerModel model1 = new SpinnerNumberModel(50, 1, 100, 1);
        SpinnerModel model2 = new SpinnerNumberModel(50, 1, 100, 1);
        sizeXSpinner = new JSpinner(model1);
        sizeYSpinner = new JSpinner(model2);

        editorPanel = new JPanel();
        databasePanel = new JPanel();
        bottomBar = new JPanel();

        feedbackMessage.setText(" ");
        feedbackMessage.setHorizontalTextPosition(JLabel.LEADING);
        bottomBar.add(feedbackMessage);
    }


    /**
     * Removes existing maze if there is one and generates a new one
     */
    private void createMaze() {
        tabbedPane.setSelectedComponent(editorPanel);

        String mazeName = mazeNameField.getText();

        int x = (Integer) sizeXSpinner.getValue();
        int y = (Integer) sizeYSpinner.getValue();

        if (firstNameField.getText().equals("")) {
            System.out.println("setting text to properties");
            firstNameField.setText(properties.getProperty(UserSettingsUI.USER_FIRST_NAME));
            lastNameField.setText(properties.getProperty(UserSettingsUI.USER_LAST_NAME));
        }

        try {
            // Clears the previous maze and its visuals
            editorPanel.removeAll();
            editorPanel.repaint();

            // Get images
            Image logo = (logoFile != null) ? ImageHelper.getImageFromFile(logoFile) : null;
            Image start = (startFile != null) ? ImageHelper.getImageFromFile(startFile) : null;
            Image end = (endFile != null) ? ImageHelper.getImageFromFile(endFile) : null;

            // Determine what kind of maze we are making
            if (autoGenerateCheck.isSelected()) {
                // Flip the x, y as rows = y and columns = x
                generator = new AutoGenerator(y, x, editorPanel.getSize(), logo, start, end);
            } else {
                generator = new EmptyGenerator(y, x, editorPanel.getSize(), logo, start, end);
            }

            // Add the maze to the screen and finalise
            editorPanel.add(generator);
            editorPanel.validate(); // Ensure that the new maze is drawn
            displayMessage("Your maze has been created", SUCCESS_COL);

        } catch (Exception e) {
            displayError(e.getMessage());
        }
    }


    /**
     * Removes existing maze if there is one and generates a new one from a loaded source
     *
     * @param mazeData The array of the maze to be loaded
     */
    public void createMaze(ArrayList mazeData) {
        try {
            String mazeName = (String) mazeData.get(0);
            int authorID = (int) mazeData.get(1);
            Timestamp created = (Timestamp) mazeData.get(2);
            Timestamp edited = (Timestamp) mazeData.get(3);
            int[][] array = convertStringToIntArray((String) mazeData.get(4));
            Image logo = (Image) mazeData.get(6);
            Image start = (Image) mazeData.get(7);
            Image end = (Image) mazeData.get(8);

            // Flip the x, y as rows = y and columns = x
            generator = new LoadedGenerator(editorPanel.getSize(), array, logo, start, end);
            this.maze = new Maze(mazeName, generator, created, edited);

            // Clears the previous maze and its visuals
            editorPanel.removeAll();
            editorPanel.repaint();

            editorPanel.add(generator);
            displayMessage("Your maze has been created", SUCCESS_COL);

            editorPanel.validate(); // Ensure that the new maze is drawn

        } catch (Exception e) {
            displayError("Could not create the maze: " + e.getMessage());
        }
    }


    /**
     * Gathers the information about mazes from the database and displays the mazes
     */
    private void createDBScreen(ArrayList mazeCollection) {
        if (mazeCollection == null) {
            displayError("There are not mazes to view. Database is empty or search result returns none.");
            return;
        }

        databasePanel.setLayout(new GridLayout(0, 4));

        // clear all existing buttons
        databasePanel.removeAll();

        //ArrayList mazeCollection = generateMazeCollection();

        MainMazeUI frame = this; // For the context menu to reference

        for (int i = 0; i < mazeCollection.size(); i++) {
            ArrayList mazeData = (ArrayList) mazeCollection.get(i);

            // Deconstruct each individual maze
            String mazeName = (String) mazeData.get(0);
            int ID = (int) mazeData.get(1);
            Timestamp created = (Timestamp) mazeData.get(2);
            Timestamp edited = (Timestamp) mazeData.get(3);
            Image image = (Image) mazeData.get(5);

            // Get author name
            String[] authorName = connection.getAuthorName(ID);

            // Parse timestamp to String
            String createdStr = created.toString().substring(0, "yyyy-MM-dd HH:mm:ss".length());
            String editedStr = edited.toString().substring(0, "yyyy-MM-dd HH:mm:ss".length());

            // Rescale the image so it can fit properly on the button
            image = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            Icon icon = new ImageIcon(image);

            // Each maze gets its own panel
            JPanel panel = new JPanel();
            //panel.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
            panel.setPreferredSize(new Dimension(300, 250));
            panel.setLayout(new FlowLayout());

            // Panel components
            JLabel nameLabel = new JLabel(mazeName + ",");
            JLabel authorLabel = new JLabel("by " + authorName[0] + " " + authorName[1] + ",");
            JLabel createdLabel = new JLabel("Date created: " + createdStr);
            JLabel editedLabel = new JLabel("Last edited: " + editedStr);

            JToggleButton toggleButton = new JToggleButton(icon);
            toggleButton.setPreferredSize(new Dimension(170, 170));
            toggleButton.addItemListener(event -> {
                if (event.getStateChange() == ItemEvent.SELECTED) {
                    // toggle
                    mazeDataArray.add(mazeData);
                } else {
                    // untoggle
                    mazeDataArray.remove(mazeData);
                }
            });

            toggleButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e)) {
                        DatabaseContextMenuUI menu = new DatabaseContextMenuUI();
                        menu.mazeInfoArrayList = mazeData;
                        menu.master = frame;
                        menu.show(e.getComponent(), e.getX(), e.getY());
                    }
                }
            });

            panel.add(nameLabel);
            panel.add(authorLabel);
            panel.add(createdLabel);
            panel.add(editedLabel);
            panel.add(toggleButton);
            databasePanel.add(panel);
        }
    }

    private ArrayList generateMazeCollection() {
        ArrayList ALL;

        try {
            ALL = connection.getAllMaze();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }

        if (ALL.size() == 0) return null;

        ArrayList name = (ArrayList) ALL.get(0);
        ArrayList authorID = (ArrayList) ALL.get(1);
        ArrayList dateCreated = (ArrayList) ALL.get(2);
        ArrayList lastEdited = (ArrayList) ALL.get(3);
        ArrayList mazeArray = (ArrayList) ALL.get(4);
        ArrayList images = (ArrayList) ALL.get(5);
        ArrayList logoImages = (ArrayList) ALL.get(6);
        ArrayList startImages = (ArrayList) ALL.get(7);
        ArrayList endImages = (ArrayList) ALL.get(8);

        ArrayList mazeCollection = new ArrayList();

        for (int i = 0; i < name.size(); i++) {
            ArrayList mazeData = new ArrayList();

            mazeData.add(name.get(i));
            mazeData.add(authorID.get(i));
            mazeData.add(dateCreated.get(i));
            mazeData.add(lastEdited.get(i));
            mazeData.add(mazeArray.get(i));
            mazeData.add(images.get(i));
            mazeData.add(logoImages.get(i));
            mazeData.add(startImages.get(i));
            mazeData.add(endImages.get(i));

            mazeCollection.add(mazeData);
        }
        return mazeCollection;
    }


    /**
     * Converts a string to an int array
     * Credit: akhil_mittal from <a href="https://stackoverflow.com/a/33167435">...</a>
     *
     * @param string The string to transform into an array
     */
    public static int[][] convertStringToIntArray(String string) {
        // Let it be known that I wasted 3hrs on this before giving up and doing it the bad way XD
        String[] strings = string.replace("[", "").replace("]", ">").split(", ");
        List<String> stringList = new ArrayList<>();
        List<String[]> tempResult = new ArrayList<>();
        for (String str : strings) {
            if (str.endsWith(">")) {
                str = str.substring(0, str.length() - 1);
                if (str.endsWith(">")) {
                    str = str.substring(0, str.length() - 1);
                }
                stringList.add(str);
                tempResult.add(stringList.toArray(new String[stringList.size()]));
                stringList = new ArrayList<>();
            } else {
                stringList.add(str);
            }
        }
        String[][] originalArray = tempResult.toArray(new String[tempResult.size()][]);

        int[][] array = new int[originalArray.length][originalArray[0].length];

        for (int i = 0; i < originalArray.length; i++) {
            for (int j = 0; j < originalArray[0].length; j++) {
                array[i][j] = Integer.parseInt(originalArray[i][j]);
            }
        }
        return array;
    }


    /**
     * Replaces any open fileChooser and repurposes it to display a browser for
     * the desired image type (logo, start, or end).
     * Is also used for saving images.
     *
     * @param fileDisplayField The display field in the GUI
     * @return Image file if the user chooses one, else null
     */
    private static File createFileChooser(JTextField fileDisplayField, String buttonText) {
        if (fileChooser != null) fileChooser.cancelSelection();

        fileChooser = new JFileChooser(new File(System.getProperty("user.home")));
        // Set text
        fileChooser.setDialogTitle(buttonText);
        fileChooser.setApproveButtonText(buttonText);
        // Remove "All files" filter
        fileChooser.removeChoosableFileFilter(fileChooser.getFileFilter());
        // Filter to jpg, png
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Supported formats( .jpg  .png )", "jpg", "png");
        fileChooser.addChoosableFileFilter(filter);

        // Get the user's button choice ( Open or Cancel )
        int choice = fileChooser.showOpenDialog(null);
        if (choice == JFileChooser.CANCEL_OPTION) {
            if (fileDisplayField != null) fileDisplayField.setText("");
            return null;
        }

        File file = fileChooser.getSelectedFile();
        if (fileDisplayField != null) fileDisplayField.setText(file.getName());
        return file;
    }


    /**
     * Replaces any open fileChooser and repurposes it to display a browser for
     * the desired image type (logo, start, or end).
     * Is also used for saving images.
     *
     * @param fileDisplayField The field to display the image path in
     * @return file class with the details of the file/destination
     */
    private static File createFileChooser(JTextField fileDisplayField) {
        return createFileChooser(fileDisplayField, "Open");
    }


    /**
     * Replaces any open fileChooser and repurposes it to display a browser for
     * the desired image type (logo, start, or end).
     * Is also used for saving images.
     *
     * @param buttonText The text displayed on the approval option
     * @return file class with the details of the file/destination
     */
    private static File createFileChooser(String buttonText) {
        return createFileChooser(null, buttonText);
    }


    /**
     * Display a helpful message at the bottom of the screen to the user to
     * inform them of an error or success of a background process
     *
     * @param message The helpful error to display
     * @param colour  The colour of the displayed message
     */
    public static void displayMessage(String message, String colour) {
        String string = String.format(MESSAGE_FORMAT, colour, message);
        feedbackMessage.setText(string);
    }

    /**
     * Display a helpful error at the bottom of the screen to the user to
     * inform them of an error of a background process
     *
     * @param message The helpful error to display
     */
    public static void displayError(String message) {
        displayMessage(message, ERROR_COL);
    }
}