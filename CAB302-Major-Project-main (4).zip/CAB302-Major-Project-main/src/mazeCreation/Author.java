package mazeCreation;

/**
 * mazeCreation.Author class provides structure for an author object.
 */
public class Author {
    private final String authorFirstName;
    private final String authorLastName;

    /**
     * @param firstName - Authors first name
     * @param lastName - Authors last name
     */
    public Author(String firstName, String lastName) {
        this.authorFirstName = firstName;
        this.authorLastName = lastName;
    }

    public String getAuthorFirst() {return authorFirstName;}
    public String getAuthorLast() {return authorLastName;}

    @Override
    public String toString() {
        return authorFirstName + " " + authorLastName;
    }

}
