package mazeCreation;

/**
 * Thrown if there is an issue creating a Maze
 */
public class MazeConstructorException extends Exception {
    public MazeConstructorException(String message) {
        super(message);
    }
}