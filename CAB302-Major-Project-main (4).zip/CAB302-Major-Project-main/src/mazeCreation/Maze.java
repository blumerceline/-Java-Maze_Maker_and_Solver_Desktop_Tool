package mazeCreation;

import davidJEck.Generator;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.Timestamp;


/**
 * Maze interface provides functionality needed by any classes for the maze
 * application
 */
public class Maze {
    public String mazeName;
    public Timestamp dateTimeCreated;
    public Timestamp dateTimeLastModified;
    public Generator generator;


    /**
     * The implementation of maze
     *
     * @param mazeName - The name of the maze
     * @throws MazeConstructorException - With different messages for the user on why a maze can't be created
     */
    public Maze(String mazeName, Generator generator, Timestamp dateTimeCreated, Timestamp dateTimeLastModified) throws MazeConstructorException {
        if (mazeName.isBlank()) {
            throw new MazeConstructorException("Please enter a name");
        }
        if (mazeName.length() > 50) {
            throw new MazeConstructorException("Maze name is limited to 50 characters");
        }

        this.mazeName = mazeName;
        this.dateTimeCreated = dateTimeCreated;
        this.dateTimeLastModified = dateTimeLastModified;
        this.generator = generator;
    }


    public String getMazeName() {
        return mazeName;
    }

    public Timestamp getDateTimeCreated() {
        return dateTimeCreated;
    }

    public Timestamp getDateTimeLastModified() {
        return dateTimeLastModified;
    }
    
    public String getMazeArray() {
        return generator.toString();
    }


    /**
     * Gets a thumbnail image of the existing maze in the editor
     * @return thumbnail image
     */
    public Image getThumbnailImage() {
        // CREDIT TO CELINE D:
        Dimension size = generator.getSize();
        BufferedImage image = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = image.createGraphics();
        generator.paint(g2);
        g2.dispose();

        try {
            ImageIO.write(image, "png", new File("snapshot.png"));
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return image.getScaledInstance(size.width / 4, size.height / 4, Image.SCALE_SMOOTH);
    }
}
