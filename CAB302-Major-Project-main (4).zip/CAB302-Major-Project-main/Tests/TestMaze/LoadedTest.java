package TestMaze;

import davidJEck.Generator;
import davidJEck.LoadedGenerator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoadedTest {

    @Test
    public void NumberofDeadEnds() throws Exception{
        int[][] maze3 = {
                {1,1,1,1,1},
                {1,3,3,3,1},
                {1,1,1,3,1},
                {1,1,1,3,1},
                {1,1,1,1,1}};
        Generator generator6 = new LoadedGenerator(maze3);
        generator6.solveMaze(1,1);
        double runAnswer = generator6.numberOfDeadEnds();
        double expectedAnswer = 40.0d;
        assertEquals(expectedAnswer, runAnswer);
    }


    // tests cells reached by solution
    @Test
    public void CellsReachedTest() throws Exception{
        int[][] maze2 = {
                {1,1,1,1,1},
                {1,3,3,3,1},
                {1,3,3,3,1},
                {1,3,3,3,1},
                {1,1,1,1,1}};
        Generator generator5 = new LoadedGenerator(maze2);
        generator5.solveMaze(1,1);
        double runAnswer = generator5.cellsReachedBySolution();
        double expectedAnswer = 100.0d;
        assertEquals(expectedAnswer, runAnswer);
    }
}
