package TestMaze;

import davidJEck.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.*;


// TODO: generate 5x5 maze, dead cells count is correct, cells reached by solution is correct

public class GeneratorTester {

    @Test
    public void SolveMazeEmpty() {
        Generator generator4 = new EmptyGenerator(3,3, new Dimension(5,5),
                null, null, null);
        generator4.solveMaze(1,1);
        int[][] maze = generator4.getMaze();
        boolean runAnswer = maze[3][3] == Generator.pathCode;

        boolean expectedAnswer = true;
        assertEquals(expectedAnswer, runAnswer);
    }




}