package TestMaze;

import davidJEck.*;
import mazeCreation.Author;
import mazeCreation.Maze;
import org.junit.jupiter.api.*;

import java.sql.Timestamp;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MazeTest {
    private final int stringLimit = 50;
    public final Author safeAuthor = new Author("Maven", "Jenkins");
    public Date date = new Date();
    public Timestamp ts = new Timestamp(date.getTime());

    int[][] maze = {
            {1, 1, 1, 1, 1},
            {1, 3, 3, 3, 1},
            {1, 3, 3, 3, 1},
            {1, 3, 3, 3, 1},
            {1, 1, 1, 1, 1}};
    Generator validGenerator = new LoadedGenerator(maze);


    //============ Successful cases ===========================================
    @Test
    public void TestMazeShortestName() throws Exception {
        String name = "a";

        Maze maze = new Maze(name, validGenerator, ts, ts);
        boolean runAnswer = maze.getMazeName().length() <= stringLimit;
        boolean expectedAnswer = true;
        assertEquals(expectedAnswer, runAnswer);
    }


    @Test
    public void TestMazeLongestName() throws Exception {
        String name = "Java has some strange string behaviours because st";

        Maze maze = new Maze(name, validGenerator, ts, ts);
        boolean runAnswer = maze.getMazeName().length() <= stringLimit;
        boolean expectedAnswer = true;
        assertEquals(expectedAnswer, runAnswer);
    }


    //@Test
    //public void TestMazeSizeSmallest() throws Exception {
    //    int size = 1;
    //    Maze maze = new Maze(safeName, kaz, size, size, false);
    //    String runAnswer = String.format("%dx%d", maze.getSizeX(), maze.getSizeY());
    //    String expectedAnswer = String.format("%dx%d", size, size);
    //    assertEquals(runAnswer, expectedAnswer);
    //}

    //@Test
    //public void TestMazeSizeLargest() throws Exception {
    //    Maze maze = new Maze(safeName, kaz, 100, 100, false);
    //    String runAnswer = String.format("%dx%d", maze.getSizeX(), maze.getSizeY());
    //    String expectedAnswer = "100x100";
    //    assertEquals(runAnswer, expectedAnswer);
    // }


    //============ Fail cases =================================================


    @Test
    public void TestMazeNameTooShort() {
        String name = "";

        assertThrows(Exception.class, () -> {
            Maze maze = new Maze(name, validGenerator, ts, ts);
        });
    }

    @Test
    public void TestMazeNameTooLong() {
        String name = "Java has some strange string behaviours because str";
        assertThrows(Exception.class, () -> {
            Maze maze = new Maze(name, validGenerator, ts, ts);
        });
    }


    //@Test
    //public void TestMazeSizeTooSmall() {
    //    int size = 0;
    //    assertThrows(Exception.class, () -> {
    //        Maze maze = new Maze("test", kaz, size, size, false);
    //    });
    //}

    //@Test
    //public void TestMazeSizeTooLarge() {
    //    assertThrows(Exception.class, () -> {
    //        Maze maze = new Maze("test", kaz, 101, 101, false);
    //    });
    //}
}