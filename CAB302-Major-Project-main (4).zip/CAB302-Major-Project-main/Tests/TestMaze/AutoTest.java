package TestMaze;

import davidJEck.AutoGenerator;
import davidJEck.Generator;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.util.concurrent.CountDownLatch;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AutoTest {

    private CountDownLatch lock = new CountDownLatch(1);


    @Test
    public void MaxMazeSize() throws Exception {

        // generators will add two to row and column for border.
        Generator generator3 = new AutoGenerator(97, 97, new Dimension(5, 5),
                null, null, null);

        int[][] maze = generator3.getMaze();

        //lock.await(5000, TimeUnit.MILLISECONDS);

        String runAnswer = String.format("%dx%d", maze.length, maze[1].length);
        String expectedAnswer = "99x99";
        assertEquals(expectedAnswer, runAnswer);
    }


    @Test
    public void MinMazeSize() throws Exception {

        // generators will add two to row and column for border.
        Generator generator2 = new AutoGenerator(1, 1, new Dimension(5, 5),
                null, null, null);

        int[][] maze2 = generator2.getMaze();
        String runAnswer = String.format("%dx%d", maze2.length, maze2[1].length);
        String expectedAnswer = "3x3";
        assertEquals(expectedAnswer, runAnswer);
    }
}
